<!-- load file layout chung -->
<?php $this->layoutPath = "Layout.php"; ?>
<style type="text/css">
	img{margin: auto; margin-top: -27px; margin-left: -10px;}
</style>
	<img src="../assets/backend/layout1/img/banner_fs.jpg" width="1300">

