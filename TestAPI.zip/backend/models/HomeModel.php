<?php 
	trait HomeModel{
		
	}
 ?>